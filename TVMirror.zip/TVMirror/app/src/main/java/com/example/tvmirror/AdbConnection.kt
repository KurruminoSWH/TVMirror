package com.example.tvmirror

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.min

/** Cliente ADB mínimo sobre USB host: conexión, autenticación, streams, push (sync) y shell. */
class AdbConnection(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint,
    private val keys: KeyPair
) {
    companion object {
        const val CNXN = 0x4e584e43; const val AUTH = 0x48545541; const val OPEN = 0x4e45504f
        const val OKAY = 0x59414b4f; const val CLSE = 0x45534c43; const val WRTE = 0x45545257
    }

    class Packet(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    @Volatile private var maxData = 4096
    @Volatile private var alive = true
    @Volatile private var closedOnce = false
    private var readerThread: Thread? = null
    private val streams = ConcurrentHashMap<Int, Stream>()
    private var nextId = 1
    var banner = ""; private set
    @Volatile var failReason = ""
    @Volatile var rxBytes = 0L
    fun isAlive() = alive

    inner class Stream(val localId: Int) {
        @Volatile var remoteId = 0
        @Volatile var closed = false
        val acks = Semaphore(0)
        private val q = LinkedBlockingQueue<ByteArray>()
        private var cur: ByteArray? = null
        private var pos = 0

        fun offer(b: ByteArray) { q.put(b) }
        fun backlog() = q.size
        fun markClosed() { closed = true; acks.release(100) }

        private fun fill(): Boolean {
            while (true) {
                val c = cur
                if (c != null && pos < c.size) return true
                val n = q.poll(100, TimeUnit.MILLISECONDS)
                if (n == null) { if (closed) return false else continue }
                cur = n; pos = 0
            }
        }

        fun readFully(n: Int): ByteArray? {
            val out = ByteArray(n); var off = 0
            while (off < n) {
                if (!fill()) return null
                val c = cur!!; val k = min(n - off, c.size - pos)
                System.arraycopy(c, pos, out, off, k); pos += k; off += k
            }
            return out
        }

        fun readSome(): ByteArray? {
            if (!fill()) return null
            val c = cur!!; val r = c.copyOfRange(pos, c.size); pos = c.size; return r
        }

        fun write(data: ByteArray) {
            var off = 0
            while (off < data.size) {
                if (closed) throw IOException("Stream cerrado")
                val n = min(maxData, data.size - off)
                send(WRTE, localId, remoteId, data.copyOfRange(off, off + n))
                if (!acks.tryAcquire(10, TimeUnit.SECONDS)) throw IOException("Sin respuesta del teléfono")
                off += n
            }
        }

        fun close() {
            if (!closed) try { send(CLSE, localId, remoteId, null) } catch (e: Exception) { }
            markClosed(); streams.remove(localId)
        }
    }

    // ---------- USB bajo nivel ----------
    private fun readFully(buf: ByteArray, len: Int, timeout: Int): Boolean {
        var off = 0
        while (off < len) {
            val r = conn.bulkTransfer(inEp, buf, off, len - off, timeout)
            if (r < 0) { failReason = "lectura USB falló (recibidos $off de $len B)"; return false }
            off += r
        }
        return true
    }

    private fun parse(h: ByteArray, readData: (Int) -> ByteArray?): Packet? {
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int; val a0 = bb.int; val a1 = bb.int; val len = bb.int
        if (len < 0 || len > 4 * 1024 * 1024) return null
        val data = if (len > 0) (readData(len) ?: return null) else ByteArray(0)
        return Packet(cmd, a0, a1, data)
    }

    /** Lectura con timeout (solo para la fase de conexión). */
    private fun readPacket(timeout: Int): Packet? {
        val h = ByteArray(24)
        if (!readFully(h, 24, timeout)) return null
        return parse(h) { len -> ByteArray(len).also { if (!readFully(it, len, 5000)) return@parse null } }
    }

    /** Lectura del hilo lector: usa timeouts cortos para poder terminar limpiamente al cerrar. */
    private fun readPacketLive(): Packet? {
        val h = ByteArray(24); var off = 0
        while (alive && off < 24) {
            val t0 = System.nanoTime()
            val r = conn.bulkTransfer(inEp, h, off, 24 - off, 500)
            if (r < 0) {
                val ms = (System.nanoTime() - t0) / 1_000_000
                if (ms >= 400) continue                                      // solo timeout
                failReason = "lectura USB (cabecera) falló tras $ms ms"      // error real
                return null
            }
            off += r
        }
        if (!alive) return null
        return parse(h) { len -> ByteArray(len).also { if (!readFully(it, len, 5000)) return@parse null } }
    }

    private fun writeRaw(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = min(16384, b.size - off)
            val r = conn.bulkTransfer(outEp, b, off, n, 5000)
            if (r < 0) { failReason = "escritura USB falló (${off} de ${b.size} B)"; throw IOException("Error de escritura USB") }
            off += n
        }
    }

    @Synchronized
    fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray?) {
        val d = data ?: ByteArray(0)
        var sum = 0; for (x in d) sum += (x.toInt() and 0xff)
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        h.putInt(cmd); h.putInt(a0); h.putInt(a1); h.putInt(d.size); h.putInt(sum); h.putInt(cmd xor -1)
        writeRaw(h.array())
        if (d.isNotEmpty()) writeRaw(d)
    }

    // ---------- Conexión y autenticación ----------
    fun connect(onNeedUserApproval: () -> Unit) {
        send(CNXN, 0x01000000, 256 * 1024, "host::\u0000".toByteArray())
        var signed = false
        var deadline = System.currentTimeMillis() + 15_000     // si ya está autorizado, responde en <1 s
        while (System.currentTimeMillis() < deadline) {
            val p = readPacket(2000) ?: continue
            when (p.cmd) {
                AUTH -> {
                    if (!signed) { send(AUTH, 2, 0, AdbKeys.sign(keys, p.data)); signed = true }
                    else {
                        send(AUTH, 3, 0, AdbKeys.androidPublicKey(keys)); onNeedUserApproval()
                        deadline = System.currentTimeMillis() + 90_000   // da tiempo a aceptar el aviso
                    }
                }
                CNXN -> {
                    maxData = min(p.a1, 256 * 1024).coerceAtLeast(4096)
                    banner = String(p.data).trim('\u0000')
                    startReader(); return
                }
            }
        }
        throw IOException("Tiempo agotado: el teléfono no respondió a ADB (¿aceptaste la depuración USB?)")
    }

    private fun startReader() {
        readerThread = Thread({
            while (alive) {
                val p = readPacketLive() ?: break
                rxBytes += 24 + p.data.size
                val s = streams[p.a1]
                when (p.cmd) {
                    OKAY -> s?.let { it.remoteId = p.a0; it.acks.release() }
                    WRTE -> if (s != null) { s.offer(p.data); try { send(OKAY, p.a1, p.a0, null) } catch (e: Exception) { } }
                    CLSE -> { streams.remove(p.a1); s?.markClosed() }
                }
            }
            alive = false
            streams.values.forEach { it.markClosed() }
        }, "adb-reader").also { it.start() }
    }

    fun open(dest: String): Stream {
        val id = synchronized(this) { nextId++ }
        val s = Stream(id); streams[id] = s
        send(OPEN, id, 0, (dest + "\u0000").toByteArray())
        if (!s.acks.tryAcquire(5, TimeUnit.SECONDS) || s.closed) {
            streams.remove(id); throw IOException("No se pudo abrir $dest")
        }
        return s
    }

    private fun le32(v: Int) = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()

    /** Copia un archivo al teléfono con el protocolo sync. */
    fun push(data: ByteArray, remotePath: String) {
        val s = open("sync:")
        try {
            val spec = "$remotePath,33206".toByteArray()
            s.write("SEND".toByteArray() + le32(spec.size) + spec)
            var off = 0
            while (off < data.size) {
                val n = min(64 * 1024, data.size - off)
                s.write("DATA".toByteArray() + le32(n) + data.copyOfRange(off, off + n))
                off += n
            }
            s.write("DONE".toByteArray() + le32((System.currentTimeMillis() / 1000).toInt()))
            val r = s.readFully(8) ?: throw IOException("Sin respuesta al copiar")
            if (String(r, 0, 4) != "OKAY") throw IOException("Fallo al copiar el servidor al teléfono")
            s.write("QUIT".toByteArray() + le32(0))
        } finally { s.close() }
    }

    /** Cierra limpiamente: espera al hilo lector y libera la interfaz USB para poder reconectar. */
    fun close() {
        if (closedOnce) return
        closedOnce = true
        alive = false
        try { readerThread?.join(2000) } catch (e: Exception) { }
        try { conn.releaseInterface(iface) } catch (e: Exception) { }
        try { conn.close() } catch (e: Exception) { }
    }
}
