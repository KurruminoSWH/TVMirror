package com.example.tvmirror

import android.util.Base64
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

/** Clave RSA propia de la TV para que el teléfono la recuerde ("Permitir siempre"). */
object AdbKeys {
    fun load(dir: File): KeyPair {
        val priv = File(dir, "adbkey.pk8"); val pub = File(dir, "adbkey.x509")
        val kf = KeyFactory.getInstance("RSA")
        if (priv.exists() && pub.exists()) {
            try {
                return KeyPair(
                    kf.generatePublic(X509EncodedKeySpec(pub.readBytes())),
                    kf.generatePrivate(PKCS8EncodedKeySpec(priv.readBytes()))
                )
            } catch (e: Exception) { /* se regenera */ }
        }
        val gen = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val kp = gen.generateKeyPair()
        priv.writeBytes(kp.private.encoded); pub.writeBytes(kp.public.encoded)
        return kp
    }

    // Prefijo DigestInfo de SHA-1; ADB firma el token de 20 bytes como si ya fuera el hash.
    private val SHA1_PREFIX = byteArrayOf(
        0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    )

    fun sign(kp: KeyPair, token: ByteArray): ByteArray {
        val s = Signature.getInstance("NONEwithRSA")
        s.initSign(kp.private)
        s.update(SHA1_PREFIX + token)
        return s.sign()
    }

    private fun BigInteger.le(size: Int): ByteArray {
        val be = toByteArray(); val out = ByteArray(size)
        for (i in 0 until minOf(size, be.size)) out[i] = be[be.size - 1 - i]
        return out
    }

    /** Clave pública en el formato propio de Android (struct RSAPublicKey) + base64 + nombre. */
    fun androidPublicKey(kp: KeyPair): ByteArray {
        val pub = kp.public as RSAPublicKey
        val n = pub.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.mod(r32).modInverse(r32)).toLong().toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)
        val bb = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(64); bb.putInt(n0inv); bb.put(n.le(256)); bb.put(rr.le(256)); bb.putInt(pub.publicExponent.toInt())
        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        return (b64 + " tvmirror@tv\u0000").toByteArray()
    }
}
