package com.example.tvmirror

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class MainActivity : Activity() {
    private val TAG = "TVMirror"
    private val ACTION_PERM = "com.example.tvmirror.USB_PERMISSION"
    private val SERVER_VERSION = BuildConfig.SCRCPY_VERSION   // viene del archivo SCRCPY_VERSION

    private lateinit var usb: UsbManager
    private lateinit var root: FrameLayout
    private lateinit var sv: SurfaceView
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var reportView: TextView
    private lateinit var menu: LinearLayout
    private val menuItems = ArrayList<TextView>()
    private var menuSel = 0
    @Volatile private var surface: Surface? = null
    @Volatile private var running = false
    @Volatile private var adb: AdbConnection? = null
    @Volatile private var vw = 16
    @Volatile private var vh = 9
    private var showStats = false
    private val lines = ArrayDeque<String>()

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val d = i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (d != null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) begin(d)
            else log("Permiso USB denegado")
        }
    }

    /** Distingue "el USB se cayó físicamente" de "el servidor murió". */
    private val usbEvents = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val d = i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            when (i.action) {
                UsbManager.ACTION_USB_DEVICE_DETACHED -> log("USB: se perdió la conexión física con ${d?.productName ?: "el dispositivo"}")
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> log("USB: dispositivo conectado ${d?.productName ?: ""}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val sw = resources.displayMetrics.widthPixels
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        sv = SurfaceView(this)
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { surface = h.surface }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { surface = null }
        })
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(40, 30, 40, 30)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        stats = TextView(this).apply {
            setTextColor(Color.GREEN); textSize = 16f; setPadding(40, 20, 40, 20)
            setShadowLayer(4f, 0f, 0f, Color.BLACK); visibility = View.GONE
        }
        // Panel de reportes (a la derecha)
        reportView = TextView(this).apply {
            setBackgroundColor(0xEE000000.toInt()); setTextColor(Color.WHITE); textSize = 13f
            typeface = Typeface.MONOSPACE; setPadding(30, 30, 30, 30); visibility = View.GONE
        }
        // Mini menú lateral
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xDD000000.toInt())
            setPadding(30, 40, 30, 40); visibility = View.GONE
        }
        menu.addView(TextView(this).apply {
            text = "MENÚ"; setTextColor(Color.LTGRAY); textSize = 16f; setPadding(20, 0, 20, 20)
        })
        listOf("Reportes", "Guardar reporte (.txt)", "Estadísticas", "Cerrar menú").forEach { t ->
            val tv = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 22f; setPadding(20, 22, 20, 22) }
            menuItems.add(tv); menu.addView(tv)
        }
        root.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(stats, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(reportView, FrameLayout.LayoutParams((sw * 0.62f).toInt(), -1, Gravity.END))
        root.addView(menu, FrameLayout.LayoutParams((sw * 0.30f).toInt(), -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyFit() }
        setContentView(root)
        updateMenu()
        Report.add("TVMirror ${BuildConfig.VERSION_NAME} · Flecha derecha = menú (reportes) · OK = estadísticas")

        val f = IntentFilter(ACTION_PERM)
        val f2 = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED); addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(usbEvents, f2, Context.RECEIVER_NOT_EXPORTED)
        } else { registerReceiver(receiver, f); registerReceiver(usbEvents, f2) }
    }

    override fun onStart() { super.onStart(); scan() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); scan() }
    override fun onStop() { super.onStop(); stopAll() }
    override fun onDestroy() { unregisterReceiver(receiver); unregisterReceiver(usbEvents); super.onDestroy() }

    // ---------- Mando: menú lateral, reportes, estadísticas ----------
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return super.onKeyDown(keyCode, event)
        val ok = keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
        if (reportView.visibility == View.VISIBLE) {
            if (ok) saveReport()
            else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_MENU) closeReport()
            return true
        }
        if (menu.visibility == View.VISIBLE) {
            when {
                keyCode == KeyEvent.KEYCODE_DPAD_UP -> { menuSel = (menuSel + menuItems.size - 1) % menuItems.size; updateMenu() }
                keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> { menuSel = (menuSel + 1) % menuItems.size; updateMenu() }
                ok -> activate()
                keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_MENU -> menu.visibility = View.GONE
            }
            return true
        }
        when {
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_MENU -> { menu.visibility = View.VISIBLE; updateMenu(); return true }
            ok -> { toggleStats(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            reportView.visibility == View.VISIBLE -> closeReport()
            menu.visibility == View.VISIBLE -> menu.visibility = View.GONE
            else -> super.onBackPressed()
        }
    }

    private fun toggleStats() {
        showStats = !showStats
        stats.visibility = if (showStats) View.VISIBLE else View.GONE
    }

    private fun updateMenu() {
        menuItems[2].text = "Estadísticas: " + if (showStats) "sí" else "no"
        menuItems.forEachIndexed { i, tv -> tv.setBackgroundColor(if (i == menuSel) 0xFF1565C0.toInt() else Color.TRANSPARENT) }
    }

    private fun activate() {
        when (menuSel) {
            0 -> { menu.visibility = View.GONE; openReport() }
            1 -> saveReport()
            2 -> { toggleStats(); updateMenu() }
            3 -> menu.visibility = View.GONE
        }
    }

    private fun openReport() { refreshReport(); reportView.visibility = View.VISIBLE }
    private fun closeReport() { reportView.visibility = View.GONE }

    private fun refreshReport() {
        Report.save(this)
        reportView.text = "=== REPORTES ===\n" + Report.header() +
            "\nCausa probable: " + Report.diagnose() + "\n\n" +
            Report.tail(20).joinToString("\n") +
            "\n\n[OK: guardar .txt en Descargas · Flecha derecha o Atrás: cerrar]"
    }

    /** Guarda el reporte como .txt en la carpeta Descargas de la TV. */
    private fun saveReport() {
        val name = "TVMirror-reporte-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
        val text = Report.fullText()
        val where = try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
                "Descargas/$name"
            } else {
                val f = File(getExternalFilesDir(null) ?: filesDir, name); f.writeText(text); f.absolutePath
            }
        } catch (e: Exception) {
            Report.save(this); "No se pudo guardar en Descargas (${e.message}). Copia en: ${Report.file(this).absolutePath}"
        }
        Toast.makeText(this, "Reporte guardado: $where", Toast.LENGTH_LONG).show()
        log("Reporte guardado: $where")
    }

    private fun stopAll() { running = false; adb?.close(); adb = null }

    private fun log(m: String) {
        Log.i(TAG, m)
        Report.add(m)
        runOnUiThread {
            for (l in m.lines()) if (l.isNotBlank()) lines.addLast(l.take(140))
            while (lines.size > 12) lines.removeFirst()
            status.text = lines.joinToString("\n"); status.visibility = View.VISIBLE
            if (reportView.visibility == View.VISIBLE) refreshReport()
        }
    }

    /** Ajusta la imagen a la TV respetando la proporción real del video (sin estirar). */
    private fun applyFit() {
        val pw = root.width; val ph = root.height
        if (pw == 0 || ph == 0) return
        val s = minOf(pw.toFloat() / vw, ph.toFloat() / vh)
        val w = (vw * s).toInt(); val h = (vh * s).toInt()
        val lp = sv.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; lp.gravity = Gravity.CENTER; sv.layoutParams = lp }
    }

    private fun onVideoSize(w: Int, h: Int) { vw = w; vh = h; runOnUiThread { applyFit() } }

    private class AdbIface(val iface: UsbInterface, val inEp: UsbEndpoint, val outEp: UsbEndpoint)

    private fun findAdb(d: UsbDevice): AdbIface? {
        for (i in 0 until d.interfaceCount) {
            val itf = d.getInterface(i)
            if (itf.interfaceClass == 255 && itf.interfaceSubclass == 66 && itf.interfaceProtocol == 1) {
                var inE: UsbEndpoint? = null; var outE: UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) inE = ep else outE = ep
                    }
                }
                if (inE != null && outE != null) return AdbIface(itf, inE, outE)
            }
        }
        return null
    }

    private fun scan() {
        if (running) return
        log("Buscando teléfono por USB…")
        val d = usb.deviceList.values.firstOrNull { findAdb(it) != null }
        if (d == null) { log("No hay teléfono con depuración USB. Conéctalo con el cable."); return }
        log("Teléfono detectado: ${d.productName ?: d.deviceName}")
        if (usb.hasPermission(d)) { begin(d); return }
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_PERM).setPackage(packageName), flags)
        usb.requestPermission(d, pi)
    }

    /**
     * Reconecta solo si la transmisión se corta. Si falla pronto varias veces seguidas,
     * baja el "perfil" (resolución/fps/opciones) para encontrar uno que funcione.
     */
    private fun begin(first: UsbDevice) {
        if (running) return
        running = true
        Thread {
            var dev: UsbDevice? = first; var fails = 0; var level = 0
            while (running && dev != null) {
                val t0 = System.currentTimeMillis()
                Report.sessions++
                try { session(dev, level) } catch (e: Throwable) { log("⚠ ${e.message ?: e.javaClass.simpleName}") }
                Report.save(this)
                if (!running) break
                if (System.currentTimeMillis() - t0 > 20_000) { fails = 0; level = 0 }
                else { fails++; level = minOf(level + 1, 3); log("Falló pronto. Siguiente intento con perfil más ligero (nivel $level).") }
                if (fails >= 8) { log("Demasiados fallos seguidos. Abre el menú > Reportes."); break }
                log("Reconectando en 2 s…")
                Thread.sleep(2000)
                dev = usb.deviceList.values.firstOrNull { findAdb(it) != null }
                if (dev == null) log("Teléfono desconectado. Conecta el cable otra vez.")
                else if (!usb.hasPermission(dev)) { log("Sin permiso USB. Reconecta el cable."); break }
            }
            running = false
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun tvSize(): Pair<Int, Int> {
        val m = windowManager.defaultDisplay.mode
        return Pair(m.physicalWidth, m.physicalHeight)
    }

    private fun readAll(s: AdbConnection.Stream): String {
        val sb = StringBuilder()
        while (true) { val b = s.readSome() ?: break; sb.append(String(b)) }
        return sb.toString()
    }

    private fun phoneSize(conn: AdbConnection): Pair<Int, Int>? {
        val out = readAll(conn.open("shell:wm size"))
        val all = Regex("(Override|Physical) size: (\\d+)x(\\d+)").findAll(out).toList()
        val m = all.firstOrNull { it.groupValues[1] == "Override" } ?: all.firstOrNull() ?: return null
        return Pair(m.groupValues[2].toInt(), m.groupValues[3].toInt())
    }

    /** Trae del teléfono las líneas del registro interno relacionadas con el fallo. */
    private fun collectLogcat(conn: AdbConnection) {
        try {
            val out = readAll(conn.open(
                "shell:logcat -d -t 600 | grep -iE 'scrcpy|app_process|AndroidRuntime|FATAL|SIGABRT|tombstone|UsbDevice|usb_|died|kill' | tail -n 20"))
            for (ln in out.lines()) if (ln.isNotBlank()) log("[logcat] " + ln.trim().take(200))
        } catch (e: Exception) { log("[logcat] no disponible: ${e.message}") }
    }

    private fun session(d: UsbDevice, level: Int) {
        val a = findAdb(d) ?: throw Exception("Interfaz ADB no encontrada")
        val c = usb.openDevice(d) ?: throw Exception("No se pudo abrir el USB")
        c.claimInterface(a.iface, true)
        val conn = AdbConnection(c, a.iface, a.inEp, a.outEp, AdbKeys.load(filesDir))
        adb = conn
        var player: VideoPlayer? = null
        try {
            log("Autenticando… (si aparece un aviso en el teléfono, acepta y marca 'Permitir siempre')")
            conn.connect { log("Esperando que aceptes la depuración USB en el teléfono…") }
            log("Conectado: ${conn.banner.take(60)}")

            // --- Resolución: TV, teléfono, decodificador y perfil (nivel) ---
            val (tvW, tvH) = tvSize()
            val (pw, ph) = phoneSize(conn) ?: Pair(1080, 2400)
            val long = maxOf(pw, ph); val short = minOf(pw, ph)
            fun dims(s: Int) = Pair(s and 7.inv(), (s.toLong() * short / long).toInt() and 7.inv())
            val cap = listOf(2560, 1920, 1280, 960)[level]
            val maxFps = if (level >= 2) 30 else 60
            val top = minOf(long, maxOf(tvW, tvH), cap)
            val ladder = listOf(top, 1920, 1600, 1280, 960).filter { it <= top }.distinct()
            var side = ladder.last(); var fps = maxFps
            val okMax = ladder.firstOrNull { val (w, h) = dims(it); VideoPlayer.supports(w, h, maxFps) }
            if (okMax != null) side = okMax else {
                fps = 30
                side = ladder.firstOrNull { val (w, h) = dims(it); VideoPlayer.supports(w, h, 30) } ?: ladder.last()
            }
            val (lw, lh) = dims(side)
            val bitrate = (lw.toLong() * lh * fps / 10).toInt().coerceIn(4_000_000, 24_000_000)
            Report.info = "Teléfono: ${conn.banner.take(80)}\nTV pantalla: ${tvW}x$tvH · Perfil $level"
            log("Perfil $level · Teléfono ${pw}x$ph · TV ${tvW}x$tvH → video ${lw}x$lh a $fps fps, ${"%.1f".format(bitrate / 1e6)} Mbps")

            val jar = try { assets.open("scrcpy-server.jar").readBytes() }
            catch (e: Exception) { throw Exception("Falta scrcpy-server.jar en assets (ver README)") }
            conn.push(jar, "/data/local/tmp/scrcpy-server.jar")

            val scid = "%08x".format(Random.nextInt(1, 0x7fffffff))
            val extra = if (level >= 2) "" else " stay_awake=true"
            val cmd = "CLASSPATH=/data/local/tmp/scrcpy-server.jar app_process / " +
                "com.genymobile.scrcpy.Server $SERVER_VERSION scid=$scid log_level=info " +
                "audio=false control=false tunnel_forward=true video_codec=h264$extra " +
                "max_size=$side video_bit_rate=$bitrate max_fps=$fps"
            val shell = conn.open("shell:$cmd")
            Thread {
                while (true) {
                    val b = shell.readSome() ?: break
                    for (ln in String(b).lines()) if (ln.isNotBlank()) log("[tel] " + ln.trim())
                }
            }.start()

            var video: AdbConnection.Stream? = null
            for (n in 1..25) {
                try { video = conn.open("localabstract:scrcpy_$scid"); break } catch (e: Exception) { Thread.sleep(300) }
            }
            if (video == null) { collectLogcat(conn); throw Exception("El servidor no respondió") }

            video.readFully(1) ?: throw Exception("Sin datos de video")      // byte "dummy"
            video.readFully(64) ?: throw Exception("Sin nombre de dispositivo")
            val meta = ByteBuffer.wrap(video.readFully(12) ?: throw Exception("Sin cabecera de video"))
            meta.int; val w = meta.int; val h = meta.int
            onVideoSize(w, h)

            var s = surface; var tries = 0
            while ((s == null || !s.isValid) && tries++ < 50) { Thread.sleep(100); s = surface }
            val p = VideoPlayer(s ?: throw Exception("Sin superficie de video"), side) { nw, nh -> onVideoSize(nw, nh) }
            player = p
            p.start(w, h)
            runOnUiThread { status.visibility = View.GONE }

            val bytesIn = AtomicLong()
            Thread {
                var lastF = 0L; var lastB = 0L
                while (adb === conn && running) {
                    Thread.sleep(1000)
                    val f = p.framesOut; val b = bytesIn.get()
                    val txt = "Perfil $level · Teléfono ${pw}x$ph · TV ${tvW}x$tvH · Video ${vw}x$vh\n" +
                        "${f - lastF} fps · ${"%.1f".format((b - lastB) * 8 / 1e6)} Mbps · cola ${video.backlog()}"
                    lastF = f; lastB = b
                    runOnUiThread { stats.text = txt }
                }
            }.start()

            var gotConfig = false
            while (running) {
                val hd = ByteBuffer.wrap(video.readFully(12) ?: break)
                val pf = hd.long; val size = hd.int
                val data = video.readFully(size) ?: break
                bytesIn.addAndGet(size.toLong())
                val config = (pf ushr 63) != 0L
                val key = ((pf ushr 62) and 1L) != 0L
                val pts = pf and ((1L shl 62) - 1)
                if (config) { if (gotConfig) p.restart(); gotConfig = true }
                p.feed(data, pts, (if (config) 2 else 0) or (if (key) 1 else 0), video.backlog() < 3)
                if (p.stalled()) throw Exception("El decodificador de la TV se detuvo")
            }
            if (running) { collectLogcat(conn); throw Exception("El teléfono cerró la transmisión") }
        } finally {
            player?.stop(); conn.close(); adb = null
        }
    }
}
