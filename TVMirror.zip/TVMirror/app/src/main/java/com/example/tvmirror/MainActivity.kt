package com.example.tvmirror

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private val TAG = "TVMirror"
    private val ACTION_PERM = "com.example.tvmirror.USB_PERMISSION"
    private val SERVER_VERSION = "3.1"          // debe coincidir con el scrcpy-server descargado
    private val SOCKET = "scrcpy_00000001"      // "scrcpy_" + scid

    private lateinit var usb: UsbManager
    private lateinit var status: TextView
    @Volatile private var surface: Surface? = null
    @Volatile private var running = false
    @Volatile private var adb: AdbConnection? = null
    private val lines = ArrayDeque<String>()

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val d = i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (d != null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) begin(d)
            else log("Permiso USB denegado")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val sv = SurfaceView(this)
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { surface = h.surface }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { surface = null }
        })
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(40, 30, 40, 30)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        root.addView(sv, FrameLayout.LayoutParams(-1, -1))
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        setContentView(root)
        val f = IntentFilter(ACTION_PERM)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStart() { super.onStart(); scan() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); scan() }
    override fun onStop() { super.onStop(); stopAll() }
    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }

    private fun stopAll() { running = false; adb?.close(); adb = null }

    private fun log(m: String) {
        Log.i(TAG, m)
        runOnUiThread {
            lines.addLast(m); while (lines.size > 12) lines.removeFirst()
            status.text = lines.joinToString("\n"); status.visibility = View.VISIBLE
        }
    }

    private class AdbIface(val iface: UsbInterface, val inEp: UsbEndpoint, val outEp: UsbEndpoint)

    private fun findAdb(d: UsbDevice): AdbIface? {
        for (i in 0 until d.interfaceCount) {
            val itf = d.getInterface(i)
            if (itf.interfaceClass == 255 && itf.interfaceSubclass == 66 && itf.interfaceProtocol == 1) {
                var inE: UsbEndpoint? = null; var outE: UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) inE = ep else outE = ep
                    }
                }
                if (inE != null && outE != null) return AdbIface(itf, inE, outE)
            }
        }
        return null
    }

    private fun scan() {
        if (running) return
        log("Buscando teléfono por USB…")
        val d = usb.deviceList.values.firstOrNull { findAdb(it) != null }
        if (d == null) { log("No hay teléfono con depuración USB. Conéctalo con el cable."); return }
        log("Teléfono detectado: ${d.productName ?: d.deviceName}")
        if (usb.hasPermission(d)) { begin(d); return }
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_PERM).setPackage(packageName), flags)
        usb.requestPermission(d, pi)
    }

    private fun begin(d: UsbDevice) {
        if (running) return
        running = true
        Thread {
            try { run(d) } catch (e: Throwable) { log("Error: ${e.message ?: e.javaClass.simpleName}") }
            finally { running = false }
        }.start()
    }

    private fun run(d: UsbDevice) {
        val a = findAdb(d) ?: throw Exception("Interfaz ADB no encontrada")
        val c = usb.openDevice(d) ?: throw Exception("No se pudo abrir el USB")
        c.claimInterface(a.iface, true)
        val conn = AdbConnection(c, a.inEp, a.outEp, AdbKeys.load(filesDir))
        adb = conn
        log("Autenticando… (si aparece un aviso en el teléfono, acepta y marca 'Permitir siempre')")
        conn.connect { log("Esperando que aceptes la depuración USB en el teléfono…") }
        log("Conectado: ${conn.banner.take(60)}")

        val jar = try { assets.open("scrcpy-server.jar").readBytes() }
        catch (e: Exception) { throw Exception("Falta scrcpy-server.jar en assets (ver README)") }
        log("Copiando servidor al teléfono (${jar.size / 1024} KB)…")
        conn.push(jar, "/data/local/tmp/scrcpy-server.jar")

        log("Iniciando servidor en el teléfono…")
        val cmd = "CLASSPATH=/data/local/tmp/scrcpy-server.jar app_process / " +
            "com.genymobile.scrcpy.Server $SERVER_VERSION scid=00000001 log_level=info " +
            "audio=false control=false tunnel_forward=true video_codec=h264 " +
            "max_size=1920 video_bit_rate=8000000 max_fps=60"
        val shell = conn.open("shell:$cmd")
        Thread {
            while (true) { val b = shell.readSome() ?: break; log("[tel] " + String(b).trim().take(150)) }
        }.start()

        var video: AdbConnection.Stream? = null
        for (n in 1..25) {
            try { video = conn.open("localabstract:$SOCKET"); break } catch (e: Exception) { Thread.sleep(300) }
        }
        if (video == null) throw Exception("El servidor no respondió")

        video.readFully(1) ?: throw Exception("Sin datos de video")      // byte "dummy"
        video.readFully(64) ?: throw Exception("Sin nombre de dispositivo")
        val meta = ByteBuffer.wrap(video.readFully(12) ?: throw Exception("Sin cabecera de video"))
        meta.int; val w = meta.int; val h = meta.int
        log("Video ${w}x$h")

        var s = surface; var tries = 0
        while ((s == null || !s.isValid) && tries++ < 50) { Thread.sleep(100); s = surface }
        val player = VideoPlayer(s ?: throw Exception("Sin superficie de video"))
        player.start(w, h)
        runOnUiThread { status.visibility = View.GONE }

        try {
            while (running) {
                val hd = ByteBuffer.wrap(video.readFully(12) ?: break)
                val pf = hd.long; val size = hd.int
                val data = video.readFully(size) ?: break
                val config = (pf ushr 63) != 0L
                val key = ((pf ushr 62) and 1L) != 0L
                val pts = pf and ((1L shl 62) - 1)
                player.feed(data, pts, (if (config) 2 else 0) or (if (key) 1 else 0))
            }
        } finally { player.stop() }
        log("Transmisión terminada. Desconecta y vuelve a conectar el cable.")
        conn.close(); adb = null
    }
}
