package com.example.tvmirror

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build

/** Reproduce el audio PCM 16 bits / 48 kHz / estéreo que manda scrcpy (audio_codec=raw). */
class AudioPlayer {
    private var track: AudioTrack? = null

    fun start() {
        val rate = 48000
        val ch = AudioFormat.CHANNEL_OUT_STEREO
        val enc = AudioFormat.ENCODING_PCM_16BIT
        val size = maxOf(AudioTrack.getMinBufferSize(rate, ch, enc), rate * 4 / 25)   // ~40 ms
        val t = if (Build.VERSION.SDK_INT >= 26) {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(enc).setChannelMask(ch).build())
                .setBufferSizeInBytes(size)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } else {
            @Suppress("DEPRECATION")
            AudioTrack(AudioManager.STREAM_MUSIC, rate, ch, enc, size, AudioTrack.MODE_STREAM)
        }
        t.play()
        track = t
    }

    fun write(b: ByteArray) { track?.write(b, 0, b.size) }

    fun stop() {
        try { track?.stop(); track?.release() } catch (e: Exception) { }
        track = null
    }
}
