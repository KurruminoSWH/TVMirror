package com.example.tvmirror

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Registro de eventos + diagnóstico automático, para poder reportar fallos. */
object Report {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    @Volatile var sessions = 0
    @Volatile var info = ""     // datos del teléfono/plan, se rellenan en la sesión

    @Synchronized fun add(msg: String) {
        for (l in msg.lines()) if (l.isNotBlank()) lines.addLast(fmt.format(Date()) + " " + l.trim().take(300))
        while (lines.size > 600) lines.removeFirst()
    }

    @Synchronized fun tail(n: Int): List<String> = lines.toList().takeLast(n)
    @Synchronized private fun all(): List<String> = lines.toList()

    fun diagnose(): String {
        val t = tail(60).joinToString("\n")
        return when {
            t.contains("Exception on thread") || t.contains("AssertionError") || t.contains("NoSuchMethod") ->
                "El servidor scrcpy falló en el teléfono (posible incompatibilidad con su versión de Android)."
            t.contains("Falta scrcpy-server") -> "El APK se compiló sin el servidor de scrcpy."
            t.contains("Tiempo agotado") -> "El teléfono no respondió a ADB: revisa el aviso de depuración USB o reconecta el cable."
            t.contains("decodificador", true) -> "El decodificador de la TV falló o se bloqueó."
            t.contains("desconectado") -> "El cable o el puerto USB se desconectó."
            t.contains("cerró la transmisión") -> "El teléfono cerró la transmisión (el servidor terminó). Mira las líneas [tel]."
            else -> "Sin causa clara todavía."
        }
    }

    fun header(): String =
        "TVMirror ${BuildConfig.VERSION_NAME} · scrcpy-server ${BuildConfig.SCRCPY_VERSION}\n" +
        "TV: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n" +
        (if (info.isNotEmpty()) info + "\n" else "") +
        "Sesiones iniciadas: $sessions"

    fun file(ctx: Context) = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "TVMirror-reporte.txt")

    fun save(ctx: Context) {
        try {
            file(ctx).writeText(header() + "\nCausa probable: " + diagnose() + "\n\n" + all().joinToString("\n"))
        } catch (e: Exception) { }
    }
}
