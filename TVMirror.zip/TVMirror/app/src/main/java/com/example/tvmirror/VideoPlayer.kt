package com.example.tvmirror

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.view.Surface

/** Decodificador H.264 por hardware que dibuja directo en la Surface, sin buffer extra. */
class VideoPlayer(private val surface: Surface) {
    private var codec: MediaCodec? = null
    private val info = MediaCodec.BufferInfo()

    fun start(w: Int, h: Int) {
        val f = MediaFormat.createVideoFormat("video/avc", w, h)
        val big = maxOf(w, h)
        f.setInteger(MediaFormat.KEY_MAX_WIDTH, big)   // permite cambio de resolución al rotar
        f.setInteger(MediaFormat.KEY_MAX_HEIGHT, big)
        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
        val c = MediaCodec.createDecoderByType("video/avc")
        c.configure(f, surface, null, 0)
        c.start()
        codec = c
    }

    fun feed(data: ByteArray, ptsUs: Long, flags: Int) {
        val c = codec ?: return
        var idx = c.dequeueInputBuffer(10_000)
        while (idx < 0) { drain(c); idx = c.dequeueInputBuffer(10_000) }
        val b = c.getInputBuffer(idx)!!
        b.clear(); b.put(data)
        c.queueInputBuffer(idx, 0, data.size, ptsUs, flags)
        drain(c)
    }

    private fun drain(c: MediaCodec) {
        while (true) {
            val o = c.dequeueOutputBuffer(info, 0)
            if (o >= 0) c.releaseOutputBuffer(o, true)       // true = dibujar ya
            else if (o == MediaCodec.INFO_TRY_AGAIN_LATER) break
        }
    }

    fun stop() {
        try { codec?.stop(); codec?.release() } catch (e: Exception) { }
        codec = null
    }
}
