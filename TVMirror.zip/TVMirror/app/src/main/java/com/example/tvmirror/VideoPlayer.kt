package com.example.tvmirror

import android.media.MediaCodec
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Decodificador H.264 por hardware que dibuja directo en la Surface. */
class VideoPlayer(
    private val surface: Surface,
    private val maxSide: Int,
    private val onSize: (Int, Int) -> Unit
) {
    private var codec: MediaCodec? = null
    private val info = MediaCodec.BufferInfo()
    @Volatile var framesOut = 0L
    @Volatile var decodeMs = 0f                      // tiempo medio dentro del decodificador
    @Volatile private var lastOutMs = System.currentTimeMillis()
    @Volatile private var inSinceOut = 0
    private var initW = 1920; private var initH = 1080
    private val inTimes = ConcurrentHashMap<Long, Long>()

    companion object {
        /** ¿El decodificador de esta TV soporta este tamaño a estos fps? */
        fun supports(w: Int, h: Int, fps: Int): Boolean = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                !ci.isEncoder && ci.supportedTypes.any { it.equals("video/avc", true) } &&
                    ci.getCapabilitiesForType("video/avc").videoCapabilities
                        .areSizeAndRateSupported(w, h, fps.toDouble())
            }
        } catch (e: Exception) { true }
    }

    fun start(w: Int, h: Int) {
        initW = w; initH = h
        val f = MediaFormat.createVideoFormat("video/avc", w, h)
        val big = maxOf(w, h, maxSide)
        f.setInteger(MediaFormat.KEY_MAX_WIDTH, big)   // permite cambio de resolución al rotar
        f.setInteger(MediaFormat.KEY_MAX_HEIGHT, big)
        f.setInteger(MediaFormat.KEY_PRIORITY, 0)              // tiempo real
        f.setInteger(MediaFormat.KEY_OPERATING_RATE, 120)      // pide al decodificador subir su reloj
        if (Build.VERSION.SDK_INT >= 30) {
            f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            // Le dice al sistema/TV que el video es de 60 fps fijos (evita cambios de modo y tirones)
            try { surface.setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE) } catch (e: Exception) { }
        }
        val c = MediaCodec.createDecoderByType("video/avc")
        c.configure(f, surface, null, 0)
        c.start()
        codec = c
        inTimes.clear()
        lastOutMs = System.currentTimeMillis(); inSinceOut = 0
    }

    /** Reinicia el decodificador (cambio de resolución/rotación). */
    fun restart() { stop(); start(initW, initH) }

    /** render=false descarta la imagen para recuperar retraso cuando hay cola acumulada. */
    fun feed(data: ByteArray, ptsUs: Long, flags: Int, render: Boolean) {
        val c = codec ?: return
        var idx = c.dequeueInputBuffer(10_000); var waited = 0
        while (idx < 0) {
            drain(c, render)
            if (++waited > 300) throw IOException("Decodificador bloqueado")
            idx = c.dequeueInputBuffer(10_000)
        }
        val b = c.getInputBuffer(idx)!!
        b.clear(); b.put(data)
        if ((flags and 2) == 0) {
            if (inTimes.size > 300) inTimes.clear()
            inTimes[ptsUs] = System.nanoTime()
        }
        c.queueInputBuffer(idx, 0, data.size, ptsUs, flags)
        inSinceOut++
        drain(c, render)
    }

    fun stalled() = inSinceOut > 60 && System.currentTimeMillis() - lastOutMs > 3000

    private fun drain(c: MediaCodec, render: Boolean) {
        while (true) {
            val o = c.dequeueOutputBuffer(info, 0)
            when {
                o >= 0 -> {
                    inTimes.remove(info.presentationTimeUs)?.let {
                        decodeMs = decodeMs * 0.9f + ((System.nanoTime() - it) / 1e6f) * 0.1f
                    }
                    c.releaseOutputBuffer(o, render)
                    if (render) framesOut++
                    lastOutMs = System.currentTimeMillis(); inSinceOut = 0
                }
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> reportSize(c.outputFormat)
                o == MediaCodec.INFO_TRY_AGAIN_LATER -> return
            }
        }
    }

    private fun reportSize(f: MediaFormat) {
        val w = if (f.containsKey("crop-right") && f.containsKey("crop-left"))
            f.getInteger("crop-right") - f.getInteger("crop-left") + 1 else f.getInteger(MediaFormat.KEY_WIDTH)
        val h = if (f.containsKey("crop-bottom") && f.containsKey("crop-top"))
            f.getInteger("crop-bottom") - f.getInteger("crop-top") + 1 else f.getInteger(MediaFormat.KEY_HEIGHT)
        if (w > 0 && h > 0) onSize(w, h)
    }

    fun stop() {
        try { codec?.stop(); codec?.release() } catch (e: Exception) { }
        codec = null
    }
}
