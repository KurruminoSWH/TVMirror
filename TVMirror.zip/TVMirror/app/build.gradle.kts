plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.tvmirror"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tvmirror"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// Sin dependencias externas: el protocolo ADB sobre USB está implementado en AdbConnection.kt
