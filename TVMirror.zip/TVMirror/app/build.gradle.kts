plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// Única fuente de verdad de la versión del servidor scrcpy (archivo SCRCPY_VERSION en la raíz)
val scrcpyVersion = rootProject.file("SCRCPY_VERSION").readText().trim()
android {
    namespace = "com.example.tvmirror"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tvmirror"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "0.5"
        buildConfigField("String", "SCRCPY_VERSION", "\"$scrcpyVersion\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// Sin dependencias externas: el protocolo ADB sobre USB está implementado en AdbConnection.kt
