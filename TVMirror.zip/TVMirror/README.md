# TVMirror (prototipo 1)

Muestra la pantalla de un teléfono Android en una TV (Google TV / Android TV) **por cable USB**,
al estilo [scrcpy](https://github.com/Genymobile/scrcpy), pero con la TV como cliente. Sin PC.

**Estado:** prototipo sin probar. Solo video (sin audio ni control todavía).

## Cómo funciona
1. La TV actúa como host USB y habla ADB con el teléfono (implementación propia en `AdbConnection.kt`).
2. Copia el `scrcpy-server` oficial al teléfono y lo ejecuta.
3. Recibe el video H.264 y lo decodifica por hardware en un `SurfaceView`.

## Requisitos
- TV/box con Android TV o Google TV y puerto USB host. Cable USB-C a USB-A (o el que encaje).
- Teléfono con **Depuración USB** activada (Ajustes > Acerca del teléfono > tocar 7 veces "Número de compilación").

## Compilar
- **GitHub Actions** (sin instalar nada): el workflow `.github/workflows/build.yml` descarga el servidor
  oficial de scrcpy y compila. El APK queda en Actions > Artifacts.
- **Android Studio**: descarga `scrcpy-server-v3.1` desde las releases oficiales de Genymobile/scrcpy,
  renómbralo a `app/src/main/assets/scrcpy-server.jar` y compila.

## Licencia
Apache 2.0. Usa el servidor de scrcpy (Apache 2.0, © Genymobile / Romain Vimont), sin modificarlo.
