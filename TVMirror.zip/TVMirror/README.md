# TVMirror (prototipo 2 (v0.3))

Muestra la pantalla de un teléfono Android en una TV (Google TV / Android TV) **por cable USB**,
al estilo [scrcpy](https://github.com/Genymobile/scrcpy), pero con la TV como cliente. Sin PC.

**Estado:** prototipo sin probar. Solo video (sin audio ni control todavía).

## Cómo funciona
1. La TV actúa como host USB y habla ADB con el teléfono (implementación propia en `AdbConnection.kt`).
2. Copia el `scrcpy-server` oficial al teléfono y lo ejecuta.
3. Recibe el video H.264 y lo decodifica por hardware en un `SurfaceView`.

## Requisitos
- TV/box con Android TV o Google TV y puerto USB host. Cable USB-C a USB-A (o el que encaje).
- Teléfono con **Depuración USB** activada (Ajustes > Acerca del teléfono > tocar 7 veces "Número de compilación").

## Compilar
- **GitHub Actions** (sin instalar nada): el workflow `.github/workflows/build.yml` descarga el servidor
  oficial de scrcpy y compila. El APK queda en Actions > Artifacts.
- **Android Studio**: descarga `scrcpy-server-v3.1` desde las releases oficiales de Genymobile/scrcpy,
  renómbralo a `app/src/main/assets/scrcpy-server.jar` y compila.

## Licencia
Apache 2.0. Usa el servidor de scrcpy (Apache 2.0, © Genymobile / Romain Vimont), sin modificarlo.

## Novedades v0.2
- Reconexión automática si la transmisión se corta.
- Imagen sin estirar (respeta la proporción), se reajusta al girar el teléfono.
- Resolución automática según TV, teléfono y decodificador (hasta 2560, 60 fps si se puede).
- Mantiene el teléfono despierto (`stay_awake`). Si hay cola de video se salta imagen para bajar el retraso.
- Botón OK/Menú del mando: muestra estadísticas (fps, Mbps, cola).

## Novedades v0.3
- scrcpy-server actualizado a **3.3.3** (la 3.1 fallaba al arrancar en Android 16). La versión vive en `SCRCPY_VERSION`.
- Corregida la reconexión (el hilo lector USB ahora termina limpio al cerrar).
- **Reportes**: flecha abajo del mando abre una pantalla con causa probable + últimas líneas del registro; también se guarda en `TVMirror-reporte.txt` (Android/data/com.example.tvmirror/files).

## Novedades v0.4
- Mini menú lateral (flecha derecha): **Reportes**, **Guardar reporte (.txt)** en Descargas, Estadísticas.
- Detecta si el USB se pierde físicamente (cable / energía del puerto) frente a un fallo del servidor.
- Al fallar, trae del teléfono las líneas de logcat relacionadas (`[logcat]`).
- Perfiles automáticos: si falla pronto, baja resolución/fps (nivel 1–3) para encontrar uno estable.
