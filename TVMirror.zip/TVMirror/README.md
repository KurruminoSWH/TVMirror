# TVMirror (prototipo, v0.7)

Muestra la pantalla de un teléfono Android en una TV (Google TV / Android TV) **por cable USB**,
al estilo [scrcpy](https://github.com/Genymobile/scrcpy), pero con la TV como cliente. Sin PC.

## Cómo funciona
1. La TV actúa como host USB y habla ADB con el teléfono (implementación propia en `AdbConnection.kt`).
2. Copia el `scrcpy-server` oficial al teléfono y lo ejecuta.
3. Recibe video H.264 (decodificación por hardware) y audio PCM, y los reproduce.

## Requisitos
- TV/box con Android TV o Google TV y puerto USB host. **Usa un cable de datos de buena calidad** (cables malos causan cortes).
- Teléfono con **Depuración USB** activada.

## Compilar
- **GitHub Actions**: el workflow descarga el servidor oficial de scrcpy (versión en `SCRCPY_VERSION`) y compila.
- **Android Studio**: descarga `scrcpy-server-v<versión>` de las releases de Genymobile/scrcpy,
  renómbralo a `app/src/main/assets/scrcpy-server.jar` y compila.

## Mando (flecha derecha = menú)
Reportes · Guardar reporte (.txt) · Calidad · Modo juego · Sonido · Pantalla del teléfono · Estadísticas.
OK = estadísticas (fps, Mbps, cola, retraso del decodificador).

## Novedades v0.7
- Baja latencia: decodificador en tiempo real, "modo juego" de la TV (ALLM), frame-rate fijo, descarte de imagen atrasada,
  medición de retraso (decodificador y cola).
- Sonido del teléfono en la TV (PCM crudo, sin codec, mínima latencia).
- Apagar la pantalla del teléfono sin cortar la transmisión.
- Modo seguro automático: si algo experimental falla al arrancar, reintenta sin audio ni opciones extra.

## Licencia
Apache 2.0. Usa el servidor de scrcpy (Apache 2.0, © Genymobile / Romain Vimont), sin modificarlo.
